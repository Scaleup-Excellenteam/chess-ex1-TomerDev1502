#include "Pieces/Piece.h"

Piece::Piece(bool isWhite, int x, int y) : m_isWhite(isWhite), m_row(x), m_col(y) {}

